#include "vec3.h"
#include <stdio.h> 
#include <iostream> 
#include <string> 
#include <vector> 



vec3::vec3()
{
}


vec3::~vec3()
{
}
