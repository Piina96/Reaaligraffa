#pragma once
class vec4
{
public:
	vec4();
	~vec4();
};

