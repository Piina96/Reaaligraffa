#include "vec2.h"
#include <stdio.h> 
#include <iostream> 
#include <string> 
#include <vector> 



vec2::vec2()
{
}


vec2::~vec2()
{
}

vec2::vec2(float _x, float _y) : x(_x), y(_y)
{

}

vec2::operator+(const vec2 rhs)
{
	return vec2(this->x + rhs.x, this->y, rhs.y);
}