#include <stdio.h> 
#include <iostream> 
#include <string> 
#include <vector> 
#include <cmath>

#include "vec2.h" 
#include "vec3.h" 
#include "vec4.h"



// Toiseen korotusta varten funktio
template <typename T> 
inline T pow2(T x)
{
	return x * x;
}


// vektori luokka
class vec2 {

public:
	float x, y;

	vec2(float _x, float _y) : x(_x), y(_y)
	{
	}



	// summalasku
	vec2 operator+(const vec2 rhs)
	{
		return vec2(this->x + rhs.x, this->y + rhs.y);
	} 

	// v�hennyslasku 
	vec2 operator-(const vec2 rhs)
	{
		return vec2(this->x - rhs.x, this->y - rhs.y); 
	} 
	// Jako ja kertomislaskut?? 
	// ristitulo 
	vec2 operator % (const vec2 rhs)
	{
		return vec2(this->x * rhs.y - this->y * rhs.x, this->y * rhs.x - this->x * rhs.y);
	} 
	// pituus 
	float len_sqr() const
	{
		return (*this) * (*this);   // Miten ??
	} 
	float len() const
	{
		return std::sqrt(len_sqr());
	}
	
};


// hyv� malli 
// https://www.ohjelmointiputka.net/koodivinkit/25084-cpp-operaattorien-ylikuormitus-3d-vektoriluokka

int main()
{
	 

	std::cout << "Teht�v� 1 reaaliaikagrafiikkaohjelmoinnin tunneille: " << std::endl;

	
}

