#pragma once
class vec3
{
public:
	vec3();
	~vec3();
};

