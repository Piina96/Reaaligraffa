#include "vec4.h"
#include <stdio.h> 
#include <iostream> 
#include <string> 
#include <vector> 



vec4::vec4()
{
}


vec4::~vec4()
{
}
